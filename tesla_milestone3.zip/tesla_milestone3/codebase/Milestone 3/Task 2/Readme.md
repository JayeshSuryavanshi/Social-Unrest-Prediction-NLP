Readme for Task 2

1. Before running the Colab notebook, install the dependencies

2. Load the Project 2 data, which consists of the tsv files required for the Task 2 i.e. Task2 Train, Validation, and Test.

3. Mount the drive in notebook and ensure that the path for accessing the above files is correctly mentioned throughtout the notebook.

4. Run the cells sequentially, and ensure that the GPU is allocated in the runtime. 


