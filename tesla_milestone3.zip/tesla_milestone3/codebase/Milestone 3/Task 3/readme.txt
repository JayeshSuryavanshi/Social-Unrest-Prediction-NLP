Task3:

1)Please ready your Bing News API keys to use the Bing News Search v7 to pull news json from AZURE. 

2)Run the DownloadBingNews.ipynb file by changing the keys for Bing News Search v7 to pull in news and the code will store it in a getBingNews.csv

3)Make sure you are in the same location as that of (2) as the next steps will require the file getBingNews.csv for execution.

4)Run the Labelling_Event_with_ACLED.ipynb file which will also need the ACLED data( please pull this from the ACLED export tool for the same dates as that of the pulled Bing News)

5)The above step will write a csv named "bingACLEDNewsMatch" which will have the labelled data ready for training.

6)Now run the Training_and_Prediction.ipynb file sequentially to obtain all the results.