Task 1 :

1) Run the file Task1Classifier.ipynb sequentially to obtain the results.
